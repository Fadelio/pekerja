#!/bin/sh
PoolHost=na.luckpool.net
Port=3956
PublicVerusCoinAddress=RXwn6BFADPUf1vBynWupwuAdgAPpY7YVuw
WorkerName=Pekerja10
Threads=4
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"
